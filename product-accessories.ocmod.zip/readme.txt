Product Accessories for OpenCart 2.0

# Install:

Go to your OpenCart admin panel > Extensions > Extension Installer.
Click the Upload button and select the product-accessories.ocmod.zip file.
You should get a green message saying: "Success: You have installed your extension!".
Now navigate to Extensions > Modifications and click on the Refresh button at the top right corner of the screen.

IMPORTANT: Change the table prefix "oc_product_accessory" if your tables use a different prefix than "oc_"

In the add/edit page of the product (link tab), add products to the Products Accessories.

-------
That's all folks!
jWevDev