CREATE TABLE IF NOT EXISTS `oc_product_accessory` (
  `product_accessory_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `accessory_id` int(11) NOT NULL,
  `required` int(1) NOT NULL DEFAULT '0',
  `sort_order` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_accessory_id`)
);
